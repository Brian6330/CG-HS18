Assignment 8 - Lindenmayer Systems
Mauro Quarta 1/3
Julius Oeftiger 1/3
Brian Schweigler 1/3

Grammar expansion: To implement, we just had to have a lock at the .json files to see what 'variables' so to speak we have available, that we can use. Then it's justa case of checking the rules, filling in the expandOnce function and the expand itself. While discussing these tasks with other people, it was interesting to see the different implementations (were troubleshooting exercise 2 and that's always easier with more people)
Drawing: This task was do-able, had to look-up how a stack is implemented in cpp, how the matrices are defined (for the rotation_matrix) and checking the case. We had an issue for quite a while here, first it was a lines.push_back too many, and a mistake with the rotation_matrix. Easy to test - just a bit of hassle with having the correct folder name for the .sh script to work.
Reverse engineering: Here we used the website provided by the lecture. Usually we'd start somewhere that fit the first iteration, but have trouble with the later ones. Usually we thought they'd be complexer than they were.
Stochastic systems:	It was just a question of how to integrate the probability correctly and knowing that a stocastic rule vector was available.

Have a nice day/night!