Assignment 5 - Transformations and Viewing
Mauro Quarta 1/3
Julius Oeftiger 1/3
Brian Schweigler 1/3


Placing objects in the scene is a little confusing with the maths, it would be nice to have a simpler picture than the one from the Assignment.pdf.
Same goes for the eye. It works, but it's still not quite clear to us hence we aren't sure if everything is completely correct.
Rendering the textured objects was easy, as we could just re-use most of the code that was used for rendering the sun.
Responding to keyboard events was also just following the other templates, so-to-speak.
The spaceship camera view has to be adjusted a bit with arrows and zoom out, or it will look like in the pictures. We hope it behaves as wanted,
some angles had to be adjusted in code, to "hide" mistakes.

The screenshots included, are of every planet, zooming in/out, moving the ship from 1 position to another


We hope you're happy with all of this and wish you a nice day/night!