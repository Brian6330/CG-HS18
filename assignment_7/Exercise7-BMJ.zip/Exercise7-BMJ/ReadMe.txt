Assignment 7 - Shadow and Cube Mapping
Mauro Quarta 1/3
Julius Oeftiger 1/3
Brian Schweigler 1/3

 * First off, we'd like to complain about the original ReadMe supplied with the exercise. Trying to run this project on Windows in Visual Studio the way described, leads to an error. (see. Error Message.jpg) Please, adjust the ReadMe next time, as 2 out of 3 members spent the first hour(s) trying to get the project working and trying various band-aid fixes from the internet and just generally being annoyed.
	The solution was running it the same way we ran Assignment 1 if we recall correctly, from the (Power)Shell via ShadowViewer.exe ..\meshes\confused.off  (or whatever texture you're using to test). Please test on the operating systems / methods you provide in the ReadMe if you do provide them, we kept looking for bugs on our end systems. With that out of the way:

 * Inserting the old solution wasn't much of a hassle, just needed to be done.
 
 * The Projection and view Matrices were doable, once we got an overview of all the supplemental theory provided in the assignment_7.pdf. Having a case for each face and the values for the light projection matrix are gained from the .pdf / exercise slides to be filled in
 
 * Blending is just following the documentation / party following the last assignment.

 * In the 2 .frag documents, the length function was a big help as well as the solution from assignemnt 6 from which a part could be kept before continuing on with the to-do. Naming some more variables makes it easier to keep an overview.

Have a nice day/night!
